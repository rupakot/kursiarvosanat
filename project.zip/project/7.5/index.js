const http = require('http');
const fs = require('fs');
const url = require('url');

const server = http.createServer((req, res) => {
    const parsedUrl = url.parse(req.url, true);

    // Routing
    if (parsedUrl.pathname === '/' || parsedUrl.pathname === '/home') {
        serveHtmlFile('index.html', res);
    } else if (parsedUrl.pathname === '/categories') {
        serveHtmlFile('categories.html', res);
    } else if (parsedUrl.pathname === '/products') {
        serveProductPage('products.html', res);
    } else if (parsedUrl.pathname === '/add') {
        serveHtmlFile('add.html', res);
    } else if (parsedUrl.pathname === '/remove') {
        serveHtmlFile('remove.html', res);
    } else if (parsedUrl.pathname === '/tuote') {
        const productId = parsedUrl.query.id;
        getProductDetails(productId, res);
    } else if (parsedUrl.pathname === '/lisaa') {
        if (req.method === 'GET') {
            serveHtmlFile('add.html', res);
        } else if (req.method === 'POST') {
            // Handle adding product (POST request)
            // Implement logic to add product to database or file
            // Redirect to a different page after adding product
            res.writeHead(302, { 'Location': '/' });
            res.end();
        }
    } else if (parsedUrl.pathname === '/poista') {
        if (req.method === 'GET') {
            serveHtmlFile('remove.html', res);
        } else if (req.method === 'POST') {
            // Handle removing product (POST request)
            // Implement logic to remove product from database or file
            // Redirect to a different page after removing product
            res.writeHead(302, { 'Location': '/' });
            res.end();
        }
    } else if (parsedUrl.pathname === '/styles.css') {
        serveCssFile('styles.css', res);
    } else {
        res.writeHead(404);
        res.end('404 Not Found');
    }
});

const PORT = process.env.PORT || 3000;

server.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});

function serveHtmlFile(filename, res) {
    fs.readFile(filename, (err, data) => {
        if (err) {
            res.writeHead(404);
            res.end('404 Not Found');
        } else {
            res.writeHead(200, { 'Content-Type': 'text/html' });
            res.end(data);
        }
    });
}

function serveCssFile(filename, res) {
    fs.readFile(filename, (err, data) => {
        if (err) {
            res.writeHead(404);
            res.end('404 Not Found');
        } else {
            res.writeHead(200, { 'Content-Type': 'text/css' });
            res.end(data);
        }
    });
}

function getProductDetails(productId, res) {
    // Implement logic to fetch product details from database or file
    // For now, just sending a dummy response
    const product = {
        id: productId,
        name: 'Product Name',
        description: 'Product Description',
        price: '$10',
        category: 'Category Name'
    };

    if (product) {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(product));
    } else {
        res.writeHead(404);
        res.end('Product not found');
    }
}

function serveProductPage(filename, res) {
    fs.readFile(filename, (err, data) => {
        if (err) {
            res.writeHead(404);
            res.end('404 Not Found');
        } else {
            fs.readFile('products.json', (err, jsonData) => {
                if (err) {
                    res.writeHead(404);
                    res.end('404 Not Found');
                } else {
                    const products = JSON.parse(jsonData);
                    const productListHtml = products.map(product => `<li>${product.name} - ${product.price} (${product.description})</li>`).join('');
                    const productHtml = data.toString().replace('{{productList}}', `<ul>${productListHtml}</ul>`);
                    res.writeHead(200, { 'Content-Type': 'text/html' });
                    res.end(productHtml);
                }
            });
        }
    });
}
