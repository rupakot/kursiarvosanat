const express = require('express');
const path = require('path');
const fs = require('fs').promises;
const bodyParser = require('body-parser');

const app = express();
const PORT = process.env.PORT || 3000;

// Serve static files (CSS, images, etc.)
app.use(express.static(path.join(__dirname, 'public')));
// Middleware to parse JSON data
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Home route
app.get('/', async (req, res) => {
    try {
        const content = await fs.readFile(path.join(__dirname, 'public', 'index.html'), 'utf8');
        res.send(content);
    } catch (error) {
        console.error(error);
        res.status(500).send('Server Error');
    }
});

// Categories route
app.get('/categories', async (req, res) => {
    try {
        const productsData = await fs.readFile(path.join(__dirname, 'data', 'products.json'), 'utf8');
        const products = JSON.parse(productsData);
        
        // Extract unique categories
        const categories = [...new Set(products.map(product => product.category))];

        let categoriesHtml = '<ul>';
        categories.forEach(category => {
            categoriesHtml += `<li>${category}</li>`;
        });
        categoriesHtml += '</ul>';

        const content = `
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Categories</title>
                <link rel="stylesheet" href="/style.css">
            </head>
            <body>
                <header>
                    <h1>SPA Example - Categories</h1>
                    <nav>
                        <ul>
                            <li><a href="/">Home</a></li>
                            <li><a href="/categories">Categories</a></li>
                            <li><a href="/products">Products</a></li>
                            <li><a href="/add">Add Product</a></li>
                            <li><a href="/remove">Remove Product</a></li>
                        </ul>
                    </nav>
                </header>
                <main>
                    <h2>Categories</h2>
                    ${categoriesHtml}
                </main>
                <script src="/script.js"></script>
            </body>
            </html>
        `;
        res.send(content);
    } catch (error) {
        console.error(error);
        res.status(500).send('Server Error');
    }
});

// Products route
app.get('/products', async (req, res) => {
    try {
        const productsData = await fs.readFile(path.join(__dirname, 'data', 'products.json'), 'utf8');
        const products = JSON.parse(productsData);
        let productsHtml = '<ul>';
        products.forEach(product => {
            productsHtml += `<li>Name: ${product.name}, Description: ${product.description}, Price: ${product.price}, Category: ${product.category}</li>`;
        });
        productsHtml += '</ul>';

        const content = `
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Products</title>
                <link rel="stylesheet" href="/style.css">
            </head>
            <body>
                <header>
                    <h1>SPA Example - Products</h1>
                    <nav>
                        <ul>
                            <li><a href="/">Home</a></li>
                            <li><a href="/categories">Categories</a></li>
                            <li><a href="/products">Products</a></li>
                            <li><a href="/add">Add Product</a></li>
                            <li><a href="/remove">Remove Product</a></li>
                        </ul>
                    </nav>
                </header>
                <main>
                    <h2>Products</h2>
                    ${productsHtml}
                </main>
                <script src="/script.js"></script>
            </body>
            </html>
        `;
        res.send(content);
    } catch (error) {
        console.error(error);
        res.status(500).send('Server Error');
    }
});

// Add Product route (GET and POST)
app.get('/add', async (req, res) => {
    try {
        const content = await fs.readFile(path.join(__dirname, 'public', 'add.html'), 'utf8');
        res.send(content);
    } catch (error) {
        console.error(error);
        res.status(500).send('Server Error');
    }
});

app.post('/add', async (req, res) => {
    try {
        const { name, description, price, category } = req.body;
        // Check if any of the required fields are missing
        if (!name || !description || !price || !category) {
            return res.status(400).send('Missing fields');
        }

        const productsData = await fs.readFile(path.join(__dirname, 'data', 'products.json'), 'utf8');
        let products = JSON.parse(productsData);
        const newProduct = { name, description, price, category };
        products.push(newProduct);
        await fs.writeFile(path.join(__dirname, 'data', 'products.json'), JSON.stringify(products, null, 2));
        res.redirect('/products');
    } catch (error) {
        console.error(error);
        res.status(500).send('Server Error');
    }
});

// Remove Product route (GET and POST)
app.get('/remove', async (req, res) => {
    try {
        const content = await fs.readFile(path.join(__dirname, 'public', 'remove.html'), 'utf8');
        res.send(content);
    } catch (error) {
        console.error(error);
        res.status(500).send('Server Error');
    }
});

app.post('/remove', async (req, res) => {
    try {
        let { name } = req.body;
        // Trim any leading/trailing spaces
        name = name.trim();
        console.log('Product Name to Remove:', name);

        const productsData = await fs.readFile(path.join(__dirname, 'data', 'products.json'), 'utf8');
        let products = JSON.parse(productsData);
        console.log('Products Before Removal:', products);

        // Compare product names ignoring case and leading/trailing spaces
        const updatedProducts = products.filter(product => product.name.trim().toLowerCase() !== name.toLowerCase());
        console.log('Updated Products:', updatedProducts);

        if (products.length === updatedProducts.length) {
            // Product not found
            console.log('Product not found:', name);
            return res.status(404).send('Product not found');
        }

        await fs.writeFile(path.join(__dirname, 'data', 'products.json'), JSON.stringify(updatedProducts, null, 2));
        console.log('Product removed successfully:', name);

        // Redirect back to /products
        res.redirect('/products');
    } catch (error) {
        console.error(error);
        res.status(500).send('Server Error');
    }
});

// Start server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
