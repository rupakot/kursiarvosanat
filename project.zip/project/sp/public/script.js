// script.js

document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('addProductForm');

    form.addEventListener('submit', async (event) => {
        event.preventDefault();

        const name = form.querySelector('#name').value;
        const description = form.querySelector('#description').value;
        const price = form.querySelector('#price').value;
        const category = form.querySelector('#category').value;

        // Check if any of the fields are empty
        if (!name || !description || !price || !category) {
            const errorMessage = document.getElementById('error-message');
            errorMessage.textContent = 'All fields are required.';
            return;
        }

        const jsonData = { name, description, price, category };

        try {
            const response = await fetch('/add', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(jsonData)
            });

            if (!response.ok) {
                throw new Error('Error adding product');
            }

            // Optionally, you can handle the response here
            const result = await response.json();
            console.log('Product added:', result);

            // Redirect to products page after successful addition
            window.location.href = '/products';
        } catch (error) {
            console.error('Error:', error.message);
            // Optionally, show an error message on the page
            const errorMessage = document.getElementById('error-message');
            errorMessage.textContent = 'An error occurred. Please try again.';
        }
    });
});
