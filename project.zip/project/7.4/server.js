const fs = require('fs');
const express = require('express');
const app = express();
const path = require('path');
const htmlRenderer = require('./htmlRenderer');
const PORT = 3000;

// Data warehouse (JSON file)
const dataFilePath = path.join(__dirname, 'movies.json');
let movies = [];

// Read data from JSON file
function readData() {
  try {
    const data = fs.readFileSync(dataFilePath, 'utf8');
    movies = JSON.parse(data);
  } catch (err) {
    movies = [];
  }
}

// Save data to JSON file
function saveData() {
  const data = JSON.stringify(movies, null, 2);
  fs.writeFileSync(dataFilePath, data);
}

// Middleware to parse JSON
app.use(express.json());

// Middleware to check request headers
app.use((req, res, next) => {
  const acceptHeader = req.get('Accept');

  if (acceptHeader && acceptHeader.includes('text/html')) {
    res.sendHtml = (html) => {
      res.type('html');
      res.send(html);
    };
  } else {
    res.sendJson = (json) => {
      res.json(json);
    };
  }

  next();
});

// Test server endpoints
app.get('/movies', (req, res) => {
  const allMovies = movies;
  // Use sendHtml to send HTML response
  res.sendHtml(htmlRenderer.renderMoviesList(allMovies));
});

app.get('/movies/:title', (req, res) => {
  const title = req.params.title;
  const movie = movies.find((movie) => movie.title === title);
  // Use sendHtml to send HTML response
  res.sendHtml(htmlRenderer.renderMovieDetails(movie));
});

app.post('/movies', (req, res) => {
  const newMovie = req.body;
  movies.push(newMovie);
  saveData();
  res.sendJson({ message: 'Movie added successfully' });
});

app.delete('/movies/:title', (req, res) => {
  const title = req.params.title;
  movies = movies.filter((movie) => movie.title !== title);
  saveData();
  res.sendJson({ message: 'Movie removed successfully' });
});

app.put('/movies/:title', (req, res) => {
  const title = req.params.title;
  const { field, newValue } = req.body;
  const movieIndex = movies.findIndex((movie) => movie.title === title);
  if (movieIndex !== -1) {
    movies[movieIndex][field] = newValue;
    saveData();
    res.sendJson({ message: 'Movie edited successfully' });
  } else {
    res.status(404).sendJson({ error: 'Movie not found' });
  }
});

// Serve the HTML file
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});

// Initialize data
readData();
