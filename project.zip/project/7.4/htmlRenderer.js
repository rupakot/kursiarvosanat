  // htmlRenderer.js
module.exports = {
  renderMoviesList: function (movies) {
    let html = '<h1>Movies List</h1>';
    html += '<ul>';

    movies.forEach((movie) => {
      html += `<li>${movie.title} - ${movie.genre}</li>`;
      // Add more details as needed
    });

    html += '</ul>';
    return html;
  },

  renderMovieDetails: function (movie) {
    if (!movie) {
      return '<h1>Movie Not Found</h1>';
    }

    let html = `<h1>${movie.title}</h1>`;
    html += `<p>Genre: ${movie.genre}</p>`;
    // Add more details as needed

    return html;
  },
};
