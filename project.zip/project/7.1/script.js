const http = require('http');
const fs = require('fs').promises;
const url = require('url');
const path = require('path');
const qs = require('querystring');

const port = 3000;
const dataFilePath = path.join(__dirname, 'db.json');

const server = http.createServer(async (req, res) => {
  const parsedUrl = url.parse(req.url, true);

  if (req.method === 'POST') {
    try {
      const data = await readDataFromFile();
      let filteredData;

      let requestBody = '';

      await new Promise((resolve) => {
        req.on('data', (chunk) => {
          requestBody += chunk.toString();
        });

        req.on('end', () => {
          resolve();
        });
      });

      const formData = qs.parse(requestBody);

      if (formData.nimi) {
        filteredData = data.filter((person) =>
          person.nimi.toLowerCase() === formData.nimi.toLowerCase()
        );
      } else if (formData.ammatti) {
        filteredData = data.filter((person) =>
          person.ammatti.toLowerCase() === formData.ammatti.toLowerCase()
        );
      } else {
        res.writeHead(400, { 'Content-Type': 'text/plain' });
        res.end('Bad Request');
        return;
      }

      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(filteredData));
    } catch (error) {
      res.writeHead(500, { 'Content-Type': 'text/plain' });
      res.end('Internal Server Error');
      console.error(error);
    }
  } else {
    res.writeHead(404, { 'Content-Type': 'text/plain' });
    res.end('Not Found');
  }
});

async function readDataFromFile() {
  try {
    const fileContent = await fs.readFile(dataFilePath, 'utf8');
    return JSON.parse(fileContent);
  } catch (error) {
    // If the file doesn't exist yet, return an empty array
    if (error.code === 'ENOENT') {
      return [];
    }
    throw error;
  }
}

server.listen(port, () => {
  console.log(`Server is listening on port ${port}`);
});
