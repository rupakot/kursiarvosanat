const fs = require('fs');
const express = require('express');
const app = express();
const path = require('path');
const PORT = 3000;

// Data warehouse (JSON file)
const dataFilePath = path.join(__dirname, 'movies.json');
let movies = [];

// Read data from JSON file
function readData() {
  try {
    const data = fs.readFileSync(dataFilePath, 'utf8');
    movies = JSON.parse(data);
  } catch (err) {
    movies = [];
  }
}

// Save data to JSON file
function saveData() {
  const data = JSON.stringify(movies, null, 2);
  fs.writeFileSync(dataFilePath, data);
}

// Data storage layer functionalities
function retrieveAllMovies(req, res) {
  const allMovies = movies;
  res.json(allMovies);
}

function retrieveOneMovie(req, res) {
  const title = req.params.title;
  const movie = movies.find(movie => movie.title === title);
  res.json(movie);
}

function addOneMovie(req, res) {
  const newMovie = req.body;
  movies.push(newMovie);
  saveData();
  res.json({ message: 'Movie added successfully' });
}

function removeOneMovie(req, res) {
  const title = req.params.title;
  movies = movies.filter(movie => movie.title !== title);
  saveData();
  res.json({ message: 'Movie removed successfully' });
}

function editOneMovie(req, res) {
  const title = req.params.title;
  const { field, newValue } = req.body;
  const movieIndex = movies.findIndex(movie => movie.title === title);
  if (movieIndex !== -1) {
    movies[movieIndex][field] = newValue;
    saveData();
    res.json({ message: 'Movie edited successfully' });
  } else {
    res.status(404).json({ error: 'Movie not found' });
  }
}

// Initialize data
readData();

// Middleware to parse JSON
app.use(express.json());

// Test server endpoints
app.get('/movies', retrieveAllMovies);
app.get('/movies/:title', retrieveOneMovie);
app.post('/movies', addOneMovie);
app.delete('/movies/:title', removeOneMovie);
app.put('/movies/:title', editOneMovie);

// Serve the HTML file
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
